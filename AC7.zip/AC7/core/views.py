from django.shortcuts import render
from django.http import HttpResponse


def index(request):
    contexto={
        "titulo":"Faculdade Impacta de Tecnologia",
    }
    return render(request, "index.html", contexto)


def cadastro_aluno(request):
    contexto={
        "titulo":"Faculdade Impacta de Tecnologia",
    }
    return render(request, "cadastro_aluno.html", contexto)


def cadastro_disciplina(request):
    contexto={
        "titulo":"Faculdade Impacta de Tecnologia",
    }
    return render(request, "cadastro_disciplina.html", contexto)


def cadastro_novo_curso(request):
    contexto={
        "titulo":"Faculdade Impacta de Tecnologia",
    }
    return render(request, "cadastro_novo_curso.html", contexto)


def courses(request):
    contexto={
        "titulo":"Faculdade Impacta de Tecnologia",
        "cursos":[
            {"nome":"Redes de Computadores", "link":"/curso/descricao-redes/"},
            {"nome":"Análise e Desenvolvimento de Sistemas", "link":"/curso/ads"},
            {"nome":"Banco de Dados", "link":"/curso/bd"}
        ]
    }
    return render(request, "courses.html", contexto)

def cursos_redes(request):
    contexto={
        "titulo":"Faculdade Impacta de Tecnologia",
        "footer": "Contato: 11 3254-8300 - IMPACTA 2018 - Todos os direitos reservados."
    }
    return render(request, "cursos_redes.html", contexto)


def DescricaoCurso(request):
    contexto={
        "titulo":"Faculdade Impacta de Tecnologia",
        "footer": "Contato: 11 3254-8300 - IMPACTA 2018 - Todos os direitos reservados."
    }
    return render(request, "DescricaoCurso.html", contexto)


def Descricaoads(request):
    contexto={
        "titulo":"ADS",
        "footer": "Contato: 11 3254-8300 - IMPACTA 2018 - Todos os direitos reservados." 
    }
    return render(request, "Descricaoads.html", contexto)


def Descricaobd(request):
    contexto={
        "titulo":"Banco de Dados",
        "footer": "Contato: 11 3254-8300 - IMPACTA 2018 - Todos os direitos reservados."
    }
    return render(request, "Descricaobd.html", contexto)




def DescricaoDisciplina(request):
    contexto={
        "titulo":"Faculdade Impacta de Tecnologia",
        "footer": "Contato: 11 3254-8300 - IMPACTA 2018 - Todos os direitos reservados."
    }
    return render(request, "DescricaoDisciplina.html", contexto)


def login(request):
    contexto={
        "titulo":"Faculdade Impacta de Tecnologia",
        "footer": "Contato: 11 3254-8300 - IMPACTA 2018 - Todos os direitos reservados."
    }
    return render(request, "login.html", contexto)


def matricula(request):
    contexto={
        "titulo":"Faculdade Impacta de Tecnologia",
        "footer": "Contato: 11 3254-8300 - IMPACTA 2018 - Todos os direitos reservados."
    }
    return render(request, "matricula.html", contexto)